package com.example.movieui.module.payment.presentation

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.movieui.R
import com.example.movieui.core.route.AppRouteName

@Composable
fun PaymentScreen(
    seatNumber: String = "A1",
    date: String = "2024-01-03",
    time: String = "15:00",
    totalAmount: Double = 50.0,
    onPhoneNumberChange: (String) -> Unit = {},
    onPayButtonClick: () -> Unit = {},
    navController: NavHostController
) {
    var showPaymentSuccess by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF00008B)) // Dark blue background
            .padding(16.dp)
    ) {
        // Judul halaman
        TopAppBar(
            title = { Text("Payment", color = Color.White) }, // Teks berwarna putih
            navigationIcon = {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = null, tint = Color.White)
                }
            },
            backgroundColor = Color(0xFF00008B), // Warna latar belakang biru tua untuk AppBar
        )

        // Spacer untuk membuat ruang antara TopAppBar dan konten lainnya
        Spacer(modifier = Modifier.height(16.dp))

        // Tampilkan teks kursi, tanggal, jam, dan total harga
        PaymentInfoText("Seat: $seatNumber", textColor = Color.White) // Teks berwarna putih
        PaymentInfoText("Date: $date", textColor = Color.White) // Teks berwarna putih
        PaymentInfoText("Time: $time", textColor = Color.White) // Teks berwarna putih
        PaymentInfoText("Total Amount: $totalAmount", textColor = Color.White) // Teks berwarna putih

        // Tampilkan formulir pembayaran
        PaymentForm(
            onPhoneNumberChange = onPhoneNumberChange
        )

        // Tampilkan tombol bayar
        PaymentButton(
            onClick = {
                onPayButtonClick()
                showPaymentSuccess = true
                // Navigate to PaymentSuccessScreen on successful payment

            }
        )

        // Tampilkan pembayaran berhasil jika showPaymentSuccess adalah true
        if (showPaymentSuccess) {
            PaymentSuccessMessage()
        }
    }
}


@Composable
fun PaymentSuccessMessage() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Payment Successful!", color = Color.White, fontSize = 20.sp)
        Image(
            painter = painterResource(id = R.drawable.test), // Replace with your image resource
            contentDescription = null,
            modifier = Modifier
                .size(600.dp)
                .padding(bottom = 8.dp)
        )
        Text("Tiket Anda", color = Color.White, fontSize = 20.sp)
    }
}



@Composable
fun PaymentInfoText(text: String, textColor: Color = Color.Black) {
    Text(
        text = text,
        style = MaterialTheme.typography.body1,
        color = textColor,
        modifier = Modifier
            .padding(vertical = 8.dp)
    )
}

@Composable
fun PaymentForm(
    onPhoneNumberChange: (String) -> Unit
) {
    var phoneNumber by remember { mutableStateOf("") }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Icon di sini
        Icon(
            imageVector = Icons.Default.ShoppingCart,
            contentDescription = "Icon",
            tint = Color.White,
            modifier = Modifier
                .padding(end = 8.dp)
        )

        // Formulir pembayaran
        OutlinedTextField(
            value = phoneNumber,
            onValueChange = {
                phoneNumber = it
                onPhoneNumberChange(it)
            },
            label = { Text("Nomer Dana", color = Color.White) },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Phone),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        )
    }
}


@Composable
fun PaymentButton(onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Text("Pay Now", color = Color.White) // Teks berwarna putih
    }
}
