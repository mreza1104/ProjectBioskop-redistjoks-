package com.example.movieui.module.payment.presentation

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.movieui.R
import com.example.movieui.core.route.AppRouteName

@Composable
fun PaymentDoneScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF00008B)) // Dark blue background
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Gambar sukses pembayaran
        Image(
            painter = painterResource(id = R.drawable.test), // Replace with your payment success image resource
            contentDescription = "Payment Success Image",
            modifier = Modifier
                .size(120.dp)
                .padding(bottom = 16.dp)
        )

        // Teks sukses pembayaran
        Text(
            text = "Payment Successful!",
            style = MaterialTheme.typography.h5,
            color = Color.White,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Teks di bawah gambar
        Text(
            text = "Thank you for your purchase.",
            style = MaterialTheme.typography.body1,
            color = Color.White,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Tombol home
        Button(
            onClick = {

            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Text("Go to Home", color = Color.White)
        }
    }
}
