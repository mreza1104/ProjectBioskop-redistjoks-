package com.example.movieui.core.route

object AppRouteName {
    const val Home = "/home"
    const val Detail = "/detail"
    const val SeatSelector = "/seat-selector"
    const val Payment = "payment"


}