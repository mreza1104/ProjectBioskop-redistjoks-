package com.example.movieui.core.route


import android.annotation.SuppressLint
import androidx.compose.runtime.*
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.movieui.module.detail.presentation.DetailScreen
import com.example.movieui.module.home.model.nowPlayingMovie
import com.example.movieui.module.home.presentation.HomeScreen
import com.example.movieui.module.payment.presentation.PaymentDoneScreen
import com.example.movieui.module.payment.presentation.PaymentScreen
import com.example.movieui.module.seat_selector.presentation.SeatSelectorScreen
import java.time.LocalDate

object AppRoute {

    // Buat composition local untuk menyimpan data yang dipilih
    val LocalSelectedSeat =
        staticCompositionLocalOf<List<String>> { error("No selected seat found!") }
    val LocalSelectedDate =
        staticCompositionLocalOf<LocalDate?> { error("No selected date found!") }
    val LocalSelectedTime = staticCompositionLocalOf<String?> { error("No selected time found!") }

    @SuppressLint("ComposableDestinationInComposeScope")
    @Composable
    fun GenerateRoute(navController: NavHostController) {
        val selectedSeat = remember { mutableStateListOf<String>() }
        val selectedDate = remember { mutableStateOf<LocalDate?>(null) }
        val selectedTime = remember { mutableStateOf<String?>(null) }

        NavHost(
            navController = navController,
            startDestination = AppRouteName.Home,
        ) {
            composable(AppRouteName.Home) {
                HomeScreen(navController = navController)
            }
            composable(
                "${AppRouteName.Detail}/{id}",
                arguments = listOf(navArgument("id") { type = NavType.StringType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getString("id")
                val movie = nowPlayingMovie.first { it.id == id }

                DetailScreen(navController = navController, movie)
            }
            composable(AppRouteName.SeatSelector) {
                SeatSelectorScreen(navController = navController)
            }
            composable(AppRouteName.Payment) {
                PaymentScreen(
                    navController = navController,

                )

                }
            }
        }
    }

